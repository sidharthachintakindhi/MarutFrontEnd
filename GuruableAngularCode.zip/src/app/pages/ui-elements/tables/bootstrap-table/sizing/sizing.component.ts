import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sizing',
  templateUrl: './sizing.component.html',
  styleUrls: ['./sizing.component.css']
})
export class SizingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
