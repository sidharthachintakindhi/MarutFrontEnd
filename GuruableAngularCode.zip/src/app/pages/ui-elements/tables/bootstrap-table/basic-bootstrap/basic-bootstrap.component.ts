import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-bootstrap',
  templateUrl: './basic-bootstrap.component.html',
  styleUrls: ['./basic-bootstrap.component.css']
})
export class BasicBootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
