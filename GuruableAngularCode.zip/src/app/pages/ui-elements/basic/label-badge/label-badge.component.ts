import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-label-badge',
  templateUrl: './label-badge.component.html',
  styleUrls: ['./label-badge.component.css']
})
export class LabelBadgeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
