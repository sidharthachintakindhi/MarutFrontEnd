import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {CustomValidators} from 'ng2-validation';

@Component({
  selector: 'app-form-validation',
  templateUrl: './form-validation.component.html',
  styleUrls: ['./form-validation.component.css']
})
export class FormValidationComponent implements OnInit {
  myForm: FormGroup;
  mynumberForm: FormGroup;
  mytooltipForm: FormGroup;
  checkdropForm: FormGroup;
  submitted: boolean;

  constructor() {

    const name = new FormControl('', Validators.required);
    const password = new FormControl('', Validators.required);
    const gender = new FormControl('', Validators.required);
    const email = new FormControl('', [Validators.required, Validators.email]);

    const rpassword = new FormControl('', [Validators.required, CustomValidators.equalTo(password)]);
    this.myForm = new FormGroup({
      name: name,
      email: email,
      password: password,
      rpassword: rpassword,
      gender: gender
    });
    /*Basic validation end*/

    /*number Validation start*/
    const integer = new FormControl('', [Validators.required, CustomValidators.digits]);
    const numeric = new FormControl('', [Validators.required, CustomValidators.number]);
    const greater = new FormControl('', [Validators.required, CustomValidators.gt(50)]);
    const less = new FormControl('', [Validators.required, CustomValidators.lt(50)]);

    this.mynumberForm = new FormGroup({
      integer: integer,
      numeric: numeric,
      greater: greater,
      less: less
    });
    /*number validation end*/

    /*Tooltip Validation Start*/
    const usernameP = new FormControl('', [Validators.required]);
    const EmailP = new FormControl('', [Validators.required, Validators.email]);
    this.mytooltipForm = new FormGroup({
      usernameP: usernameP,
      EmailP: EmailP,
    });
    /*Tooltip Validation End*/

    /* component form */
    const area = new FormControl('', [Validators.required]);
    const job = new FormControl('', [Validators.required]);
    this.checkdropForm = new FormGroup({
      area: area,
      job: job,
    });
    /* end component form */
  }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.myForm);
  }

    colors = {Blue: true, Orange: true};
	
	orderBy: any;

    //level = {one : true, two : true, three : false, four : false, five : false, six : false}

	level = ["one", "two", "three"];
	
	levelvalue: any = "three";
	
	price = "2000";
	
    enablePrice(event){
        console.log('event:'+JSON.stringify(event));
    }
	
	formatedDate(){
		var inputDate = "05-07-1981";
		
        if (inputDate == undefined || inputDate.trim() =="") {
            return "";
        }
		var regexp = new RegExp('^[0-9]{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])');
		var regexp1 = new RegExp('^(0[1-9]|[12][0-9]|3[01])\-(0[1-9]|1[012])\-[0-9]{4}');
		
		//alert("inputDate:"+regex.match(inputDate));
		
        var dateArr : any;
        if (inputDate.indexOf(" ")>0) {
            inputDate = inputDate.split(' ')[0];
        }
        if (inputDate.indexOf("T")>0) {
            inputDate = inputDate.split('T')[0];
        }
        alert("inputDate="+inputDate + " chk1:" + regexp.test(inputDate) + "  chk2:"+ regexp1.test(inputDate));
        
        if(!(regexp.test(inputDate) || regexp1.test(inputDate))) {
            alert("formatedDate:"+inputDate + " is Invalid..");
            return "invalid";
        }

        if (regexp1.test(inputDate)) {
            if (inputDate.indexOf("-")>0) {
                dateArr = inputDate.split("-");
            }
            inputDate = dateArr[2]+"-"+dateArr[1]+"-"+dateArr[0];
        }

        //var outDate = dateArr[2]+"/"+dateArr[1]+"/"+dateArr[0];
        alert("outDate="+inputDate);
        return inputDate;
    }
	
	isSelected(value: string): boolean {
		
		console.log('event:'+value);
		return true;
		/*if (this.level)
		  return this.level.indexOf(value) >= 0;
		else
		  return false;*/
	  }
}
