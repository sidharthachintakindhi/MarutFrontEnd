import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-with-social',
  templateUrl: './with-social.component.html',
  styleUrls: ['./with-social.component.css']
})
export class WithSocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
