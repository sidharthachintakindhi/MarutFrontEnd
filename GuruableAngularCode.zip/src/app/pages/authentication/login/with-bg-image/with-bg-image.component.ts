import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-with-bg-image',
  templateUrl: './with-bg-image.component.html',
  styleUrls: ['./with-bg-image.component.css']
})
export class WithBgImageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
