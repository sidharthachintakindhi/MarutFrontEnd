import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-board-task',
  templateUrl: './board-task.component.html',
  styleUrls: ['./board-task.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BoardTaskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
