import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-widget-static',
  templateUrl: './widget-static.component.html',
  styleUrls: ['../../../../assets/icon/svg-animated/svg-weather.css'],
  encapsulation: ViewEncapsulation.None
})
export class WidgetStaticComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
